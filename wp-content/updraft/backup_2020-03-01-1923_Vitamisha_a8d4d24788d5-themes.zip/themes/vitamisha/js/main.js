(function () {

	new Glide('.glide', {
		startAt: 0,
		perView: 3
	}).mount();

})();